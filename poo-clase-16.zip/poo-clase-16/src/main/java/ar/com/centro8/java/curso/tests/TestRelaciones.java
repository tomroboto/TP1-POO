package ar.com.centro8.java.curso.tests;

import java.util.List;

import ar.com.centro8.java.curso.entidades.relaciones.Auto;
import ar.com.centro8.java.curso.entidades.relaciones.ClienteMayorista;
import ar.com.centro8.java.curso.entidades.relaciones.ClienteMinorista;
import ar.com.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.com.centro8.java.curso.entidades.relaciones.EmpleadoAgregaciones;
import ar.com.centro8.java.curso.entidades.relaciones.EmpleadoAsociacionSimple;
import ar.com.centro8.java.curso.entidades.relaciones.EmpleadoComposicion;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("Testeo de la clase Cuenta:");
        //Creamos un objeto de la clase cuenta:
        Cuenta cuenta1= new Cuenta(1, "Pesos argentinos");
        System.out.println(cuenta1);
        cuenta1.depositar(10000);
        cuenta1.depositar(-10000);
        cuenta1.debitar(-10000);
        cuenta1.debitar(5000);
        System.out.println("El saldo de la cuenta1 es: "+cuenta1.getSaldo());

        // cuenta1.saldo=0; da error el atributo es privado
        // cuenta1.setSaldo(0); error no existe ese setter
        cuenta1.debitar(5000);
        System.out.println(cuenta1);

        System.out.println("\nTests de a clase ClienteMinorista");
        //creamos un objeto de la clase ClienteMinorista
        ClienteMinorista cliente1= new ClienteMinorista(1, "Mario", "Baracus");
        System.out.println(cliente1);
        cliente1.setCuenta(cuenta1);
        System.out.println(cliente1);

        ClienteMinorista cliente2= new ClienteMinorista(2, "James", "Hetfield", new Cuenta(2, "Dólares"));

        //depositar 10mil a mario baracus
        //cliente1.depositar(10_000); error el método depositar no pertenece a la clase ClienteMinorista
        cliente1.getCuenta().depositar(10_000);
        System.out.println(cliente1);

        Cuenta cta2= cliente2.getCuenta();
        cta2.depositar(15000);
        System.out.println(cta2.getSaldo());
        System.out.println(cliente2);

        System.out.println("\nTest de la clase ClienteMayorista");
        ClienteMayorista cliente3= new ClienteMayorista(3, "El gallo loco", "Independencia 3");
        System.out.println(cliente3);

        //Creo un apuntador para acceder a las cuentas del cliente3
        List<Cuenta> mCuentas3= cliente3.getCuentas();
        //con el método add() agrego cuentas a la lista
        Cuenta  cuenta2= new Cuenta(2, "Reales"),
                cuenta3= new Cuenta(3,"Yuanes"),
                cuenta4= new Cuenta(3, "Yuanes");
        
        mCuentas3.add(cuenta2); //Agregamos a la cuenta2 a la lista de cuentas del cliente 3
        mCuentas3.add(cuenta3); //Agregamos a la cuenta3 a la lista de cuentas del cliente 3
        mCuentas3.add(cuenta4); //Agregamos a la cuenta4 a la lista de cuentas del cliente 3
        mCuentas3.add(new Cuenta(5, "Libras esterlinas"));
        System.out.println(cliente3.getCuentas());
        //Con el método get() obtengo las cuentas de la lista, pasando como parámetro un número entero
        //que representa al índice del elemento.
        mCuentas3.get(0).depositar(10000); //Depositamos 10mil en la cuenta 2 de reales del cliente 3

        System.out.println("\n________________________________________\n");

        //creamos un objeto de Auto
        Auto auto1= new Auto("Peugeot", "209", "Gris");
        Auto auto2= new Auto("Renault", "Clio", "Blanco");
        Auto auto3= new Auto("Citroën", "Picasso","Violeta");

        //creamos un objeto de la clase EmpleadoAsociacionSimple
        System.out.println("\nEmpleadoAsociacionSimple");
        EmpleadoAsociacionSimple empleado1= new EmpleadoAsociacionSimple(1, "Silvester", "Stallone");
        System.out.println(empleado1);
        empleado1.usarAuto(auto1);

        //creamos un objeto de la clase EmpleadoAgregaciones
        System.out.println("\nEmpleadoAgregaciones");
        EmpleadoAgregaciones empleado2= new EmpleadoAgregaciones(2, "Charles", "Chaplin");
        System.out.println(empleado2);
        empleado2.setAuto(auto2);

        //creamos un objeto de la clase EmpleadoComposicion
        EmpleadoComposicion empleado3 = new EmpleadoComposicion(0, "Homero", "Thompson", "Ford", "Taunus", "Rojo fuego");
        System.out.println(empleado3);
        System.out.println(empleado3.getAuto());

    }

}
