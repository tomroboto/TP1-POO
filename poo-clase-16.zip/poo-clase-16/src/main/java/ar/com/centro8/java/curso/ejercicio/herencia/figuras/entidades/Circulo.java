package ar.com.centro8.java.curso.ejercicio.herencia.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString 
@AllArgsConstructor 

public class Circulo extends Figura {
    private double radio;

    @Override
    public double perimetro() {
        return Math.PI*radio*2;
    }

    @Override
    public double superficie() {
        return Math.PI*Math.pow(radio, 2);
    }
}
