package ar.com.centro8.java.curso.interfaces.implementaciones;

import ar.com.centro8.java.curso.interfaces.IArchivo;

public class ArchivoTexto implements IArchivo{
    //La clase está obligada a sobreescribir todos los métodos abstractos.
    //La clase puede heredar de otra clase (extends + nombre de la clase).
    //La clase puede implementar varias interfaces (se separan con coma cada uno de los nombres de las interfaces).
    //Si una clase implementa múltiples interfaces que contienen un método default con la misma firma, la clase
    //debe sobreescribir dicho método para resolver la ambigüedad.

    private String texto;

    @Override
    public void setText(String texto) {
        System.out.printf("Guardando <'%s'> dentro de archivo de texto...", texto);
        this.texto=texto;
    }

    @Override
    public String getText() {
        return this.texto;
    }

    @Override
    public String getTipo() {
        return "Archivo de texto.";
    }
}
