package ar.com.centro8.java.curso.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString 
@AllArgsConstructor 

public class EmpleadoAsociacionSimple {
    //La asociación simple es un tipo de relación entre clases.
    //Es la menos acoplada.
    //La reconocmeos con las palabras "usa un/a".
    //Por ejemplo, en este caso, un empleado usa un auto.

    //Atributos
    private int legajo;
    private String nombre;
    private String apellido;

    public void usarAuto(Auto auto){
        System.out.println("El empleado está usando un auto de la marca "+auto.getMarca());
    }
}
