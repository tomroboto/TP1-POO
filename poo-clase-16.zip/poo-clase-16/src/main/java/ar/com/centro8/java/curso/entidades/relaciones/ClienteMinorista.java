package ar.com.centro8.java.curso.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString 
@AllArgsConstructor 

public class ClienteMinorista {
    //atributos
    private final int nro;
    private String nombre;
    private String apellido;
    private Cuenta cuenta;

    //métodos
    public ClienteMinorista(int nro, String nombre, String apellido) {
        this.nro = nro;
        this.nombre = nombre;
        this.apellido = apellido;
    }
}
