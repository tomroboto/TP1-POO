package ar.com.centro8.java.curso.interfaces.implementaciones;

import ar.com.centro8.java.curso.interfaces.IArchivo;

public class ArchivoNube implements IArchivo {
    private String texto;

    @Override
    public void setText(String texto) {
        System.out.printf("Guardando <'%s'> dentro de archivo de texto...", texto);
        this.texto=texto;
    }

    @Override
    public String getText() {
        return this.texto;
    }

    @Override
    public String getTipo() {
        return "Archivo nube.";
    }

}
