package ar.com.centro8.java.curso.entidades.relaciones.herencia;

import ar.com.centro8.java.curso.entidades.relaciones.Cuenta;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter
@ToString (callSuper = true)

public class Cliente extends Persona {
    private int numero;
    private Cuenta cuenta;
    
    public Cliente(String nombre, String apellido, int edad, Direccion direccion, int numero, Cuenta cuenta) {
        super(nombre, apellido, edad, direccion);
        this.numero = numero;
        this.cuenta = cuenta;
    }

    @Override
    public void saludar() {
        System.out.println("Hola, soy un cliente!");
    }
}
