package ar.com.centro8.java.curso.interfaces;

public interface IPagos {
    // Definimos una interfaz que servirá para cualquier clase que lo implemente.
    // Cada clase deberá definir el comportamiento y la tecnología que se necesita para implementar cada método.

    public abstract void pagarConTarjetaDeDebito(double monto);
    public abstract void pagarConTarjetaDeCredito(double monto);
    public abstract void pagarConTransferencia(double monto);
    public abstract void pagarConEfectivo(double monto);
    public abstract void pagarConQR(double monto);


    /**
     * Método que retorna el monto ingresado como parámetro, redondeado a 2 decimales
     * @param monto -> valor que se ingresa para redondear
     * @return -> el monto ingresado, redondeado en dos decimales.
     */
    default double redondearMonto(double monto){
        return Math.round(monto*100.0)/100.0;
        //Multiplicar por 100.0 corre la coma 2 lugares a la derecha
        //los números decimales que queremos conservar, se mantienen
        //Math.round() redondea a un número decimal al entero más cercano.
        //Si la parte decimal es mayor o igual a 0.5, sube al entero siguiente
        //Si la parte decimal es menor a 0.5 baja al entero actual.
        //Al dividir por 100.0 la coma se vuelve a correr dos posiciones a la izquierda,
        //pero ahora el número quedó redondeado a 2 decimales.
        //Ejemplo: 123.4567 * 100.0 -> 12345.67 -> round -> 12346 -> /100.00 -> 123.46
        //Los calculos se deben hacer con .0 para que tome los decimales.
    }
}
