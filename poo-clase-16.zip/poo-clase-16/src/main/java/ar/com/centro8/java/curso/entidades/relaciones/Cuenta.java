package ar.com.centro8.java.curso.entidades.relaciones;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter //no generamos setter, el saldo lo modificamos por medio de métodos específicos
@ToString
@RequiredArgsConstructor //crea el constructor con los atributos final

public final class Cuenta {
    //Al color la palabra reservada final en la declaración de la clase, esta clase no podrá tener clases hijas.
    //Es una medida de seguridad para que no se creen subclases que puedan sobreescribir sus métodos.
    //Atributos
    private final int nro;
    private final String moneda;
    //cuando declaramos una variable como final queda constante. Es decir que no se va a poder modificar su valor
    private float saldo;
    //los tipos de datos primitivos no son nulleables, con lo cual, nunca van a ser nulos
    //tendrán un valor predeterminado que en el caso de los tipos numéricos será 0 y para los decimales en particular 0.0

    //Métodos
    public void depositar(float monto){
        if(monto>0)this.saldo+=monto;
        else System.out.println("No se puede depositar en negativo");
    }
    public void debitar(float monto){
        if(monto>0&&monto<=saldo)this.saldo-=monto;
        else System.out.println("El monto es negativo o excede el saldo disponible");
    }
}
