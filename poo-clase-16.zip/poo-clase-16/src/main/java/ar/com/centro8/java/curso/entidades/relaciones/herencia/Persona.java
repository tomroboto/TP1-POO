package ar.com.centro8.java.curso.entidades.relaciones.herencia;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString 
@AllArgsConstructor 

public abstract class Persona {
    //No se pueden crear objetos de una clase abstracta, se utiliza el abstract para favorecer la herencia.
    //Aunque no pueda existir herencia sin ser la clase padre abstracta necesariamente.
    private String nombre;
    private String apellido;
    private int edad;
    private Direccion direccion;
    
    //public void saludar(){
    //    System.out.println("Hola, soy una persona!");
    //}
    public abstract void saludar();
    //Un método abstracto no tiene cuerpo o comportamiento.
    //La/s clase/s que hereden de Persona deben implementar los métodos abstractos.

    public void despedir(){
        System.out.println("Chau");
    }
}