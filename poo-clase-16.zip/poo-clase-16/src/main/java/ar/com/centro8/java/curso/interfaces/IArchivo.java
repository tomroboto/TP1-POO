package ar.com.centro8.java.curso.interfaces;

import ar.com.centro8.java.curso.interfaces.implementaciones.ArchivoBinario;
import ar.com.centro8.java.curso.interfaces.implementaciones.ArchivoNube;
import ar.com.centro8.java.curso.interfaces.implementaciones.ArchivoTexto;

public interface IArchivo {
    /*
    * INTERFACES EN JAVA
    *
    * Una interfaz no tiene constructores porque no se puede instanciar directamente.
    * Las variables declaradas en una interfaz son implícitamente: public static final. Por lo tanto, funcionan como constantes.
    * Una interfaz puede declarar métodos abstractos.
    * Los métodos abstractos son implícitamente: public abstract y no tienen cuerpo.
    * Una clase concreta que implemente una interfaz debe implementar sus métodos abstractos.
    * Desde Java 8, las interfaces pueden tener métodos default. Estos métodos tienen implementación y pueden ser heredados por
    * las clases que implementan la interfaz.
    * Los métodos default pueden ser sobrescritos por las clases implementadoras mediante @Override.
    * Desde Java 8 también pueden existir métodos static dentro de una interfaz. Estos métodos pertenecen a la interfaz y se llaman
    * utilizando el nombre de la interfaz.
    * Desde Java 9 también pueden existir métodos private. Se utilizan para reutilizar código internamente dentro de la propia interfaz.
    * Una clase puede implementar varias interfaces.
    * Java no permite herencia múltiple de clases, pero sí permite implementar múltiples interfaces.
    * Esto permite que una clase tenga múltiples tipos y contratos sin heredar de varias clases.
    */

    /**
     * Método para escribir en un archivo.
     * @param texto -> es el texto que se va a escribir en el archivo.
     */
    void setText(String texto); //Método público y abstracto. Si no lo declaramos así no genera error,
                                //pero es buena práctica ponerlos para mayor claridad en el código.
    
    /**
     * Método para leer un archivo
     * @return -> retorna el contenido del archivo en forma de cadena de carácteres
     */
    public abstract String getText();

    /**
     * Método que retorna el tipo de archivo
     * @return -> retorna el tipo de archivo en formato de cadena de carácteres
     */
    public abstract String getTipo();

    default void informar(){
        System.out.println("IArchivo: Interfaz para la gestión de Archivos.");
    }

    // Factory methods (Métodos de fábrica)
    // Permite centralizar la creación de instancias de las clases que implementan la interfaz.
    // Esto sirve para ocultar la lógica de instanciacion y decidir, en función de los parámetros
    // qué implementación devolver.

    public static IArchivo crearArchivo(String tipo){
        switch (tipo.toLowerCase()) {
            case "texto": return new ArchivoTexto();
            case "binario": return new ArchivoBinario();
            case "nube": return new ArchivoNube();        
            default: throw new IllegalArgumentException("Tipo de archivo no soportado: "+tipo);
        }
    }

    // Esto es un polimorfismo por interfaz.
    // Aunque el método retorne un objeto del tipo IArchivo, la instancia concreta puede ser de cualquiera 
    // de las clases que implementan la interfaz. Por lo tanto, el objeto retornado puede comportarse de distintas
    // maneras según la implementación concreta que se devuelva.
}
