package ar.com.centro8.java.curso.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter 
@ToString 
@AllArgsConstructor 

public class EmpleadoComposicion {
    // Las composiciones son de las relaciones más fuertes entre clases.
    // Una clase no tiene sentido sin la instancia de la otra clase que la compone.
    // La reconocemos con las palabras "siempre tiene un/a".
    // En este caso, un empleado siempre tiene un auto.

    private int legajo;
    private String nombre;
    private String apellido;
    @NonNull //Esta anottation de lombok indica que el valor no puede ser nulo.
    private Auto auto;
    // Si quisiera agregar un auto nulo, da error en tiempo de ejecución.
    // De esta manera nos aseguramos de que un empleado siempre tenga un auto.

    // Un ejemplo de relación de composición más fuerte, se podría dar creando el objeto de Auto
    // directamente dentro del constructor de EmpleadoComposicion.
    public EmpleadoComposicion(int legajo, String nombre, String apellido, String marca, String modelo, String color) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.auto= new Auto(marca, modelo, color);
    }
    
}
