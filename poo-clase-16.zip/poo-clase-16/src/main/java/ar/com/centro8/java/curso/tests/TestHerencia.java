package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.relaciones.Auto;
import ar.com.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Cliente;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.com.centro8.java.curso.entidades.relaciones.herencia.Persona;
import ar.com.centro8.java.curso.keywords.Automovil;

public class TestHerencia {
    public static void main(String[] args) {
        /*
        Herencia
        Es un mecanismo para reutilizar miembros de una clase.
        Esto favorece la extensión y especialización de comportamientos.
        La reconocemos con las palabras "es un/a".
        Representa la relación más fuerte entre clases.
        La clase derivada de una subclase y la clase de la que deriva, es la superclase.
        También se las conoce como clases hijas y clase padre.
        Una clase en Java solo puede tener una única superclase directa.
        Java no soporta la herencia múltiple.
        */

        //Creamos un objeto de Direccion
        Direccion direccion1= new Direccion("Salta", 10, "6", "C", "Connecticut");
        Direccion direccion2= new Direccion("9 de Julio", 66, "PB", "A", "CABA");
        Direccion direccion3= new Direccion("Medrano", 162, "2", "8", "CABA");

        /*Persona persona1= new Persona("Carlitos", "Bala", 90, direccion1);
        System.out.println(persona1);
        persona1.saludar();
        
        ERROR no se pueden crear objetos de una clase abstracta
        */
       //Creamos un objeto de la clase Empleado
       Empleado empleado1= new Empleado("Dave", "Mustaine", 67, direccion1, 10, 1_000_000);
       System.out.println(empleado1);
       empleado1.saludar();

       //Creamos un objeto de la clase Cliente
       Cliente cliente1= new Cliente("Rob", "Halford", 74, direccion3, 20, new Cuenta(1, "Dólares"));
       System.out.println(cliente1);
       cliente1.saludar();

       empleado1.despedir();
       cliente1.despedir();

       /*
        * Polimorfismo:
        * Es la capacidad de un objeto o método para tomar muchas formas, lo que permite que el mismo método
        * pueda comportarse de maneras diferentes dependiendo del contexto.
        *
        * Hay dos clases de polimorfismo:
        *
        * 1. Polimorfismo sin redefinición, es en tiempo de compilación (sobrecarga de métodos):
        *    Se produce cuando en una misma clase existen varios métodos con el mismo nombre pero con
        *    diferentes parámetros (diferentes firmas). Esto permite ejecutar acciones similares sobre
        *    distintos tipos o números de argumentos.
        *
        * 2. Polimorfismo con redefinición, es en tiempo de ejecución (sobreescritura de métodos):
        *    Se produce cuando una subclase redefine un método heredado de la superclase (usando @Override).
        *    Esto permite que una variable de tipo de la superclase pueda referenciar objetos de diferentes
        *    subclases, comportándose de manera distinta según la instancia concreta.
        */

        /*
        Persona es una clase abstracta, no se puede crear una instancia de esa clase.
        Lo que si puedo crear es una variable de referencia de Persona.
        Utilizamos para eso los constructores de las clases hijas.
        Porque dentro de la variable del tipo Persona, podemos almacenar objetos de las clases hijas
        */
        Persona persona1 = new Cliente("Ronnie James", "Dio", 94, direccion1, 2, new Cuenta(2, "Euros"));
        System.out.println(persona1);
        persona1.saludar();
        persona1= new Empleado("Osvaldo", "Civile", 70, direccion3, 30, 500_000);
        persona1.saludar();

        //-----------------------------------------------------------------------
        //Creamos un objeto de Automovil
        Automovil auto1= new Automovil("Citroën", "Picasso", "Naranja");
        System.out.println(auto1);
        System.out.println(auto1.getVelocidad());
        auto1.acelerar(100);
        System.out.println(auto1.getVelocidad());

        Automovil auto2= new Automovil("Fiat", "Dos", "Celeste");
        System.out.println(auto2);
        System.out.println(auto2.getVelocidad());
        auto2.frenar(25);
        System.out.println(auto1.getVelocidad());
        System.out.println(Automovil.getVelocidad());
        Automovil.acelerar(182);
        Automovil.frenar(12);
        System.out.println(Automovil.getVelocidad());

    }
}