package ar.com.centro8.java.curso.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter
@ToString 
@AllArgsConstructor

public class Auto {
    //Atributos
    private String marca;
    private String modelo;
    private String color;
}
