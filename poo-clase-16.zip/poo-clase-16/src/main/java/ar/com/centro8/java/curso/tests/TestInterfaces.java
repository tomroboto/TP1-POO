package ar.com.centro8.java.curso.tests;

import java.util.Scanner;

import ar.com.centro8.java.curso.interfaces.IArchivo;

public class TestInterfaces {
    public static void main(String[] args) {
        //Creamos una referencia a la interfaz.
        IArchivo archivo;

        Scanner sc= new Scanner(System.in);
        System.out.println("Ingrese una oracion: ");
        String mensaje= sc.nextLine();
        System.out.println("Seleccione en qué tipo de archivo quiere guardar su texto:");
        System.out.println("BINARIO - TEXTO - NUBE");
        String opcion= sc.nextLine();
        sc.close();

        archivo= IArchivo.crearArchivo(opcion);
        
        archivo.setText(mensaje);
        archivo.informar();
        System.out.println(archivo.getTipo());
        System.out.println("El contenido del archivo es: "+archivo.getText());
    }
}
