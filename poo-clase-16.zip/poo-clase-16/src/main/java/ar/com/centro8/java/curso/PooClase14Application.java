package ar.com.centro8.java.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooClase14Application {

	public static void main(String[] args) {
		SpringApplication.run(PooClase14Application.class, args);
	}

}
