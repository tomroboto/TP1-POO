package ar.com.centro8.java.curso.ejercicio.encapsulamiento.figuras.entidades;

public abstract class Figura {
    public abstract double perimetro();
    public abstract double superficie();
}