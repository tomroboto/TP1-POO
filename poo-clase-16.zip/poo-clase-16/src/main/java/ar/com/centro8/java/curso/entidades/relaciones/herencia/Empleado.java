package ar.com.centro8.java.curso.entidades.relaciones.herencia;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString (callSuper = true)
//El parámetro callSuper= true le indica a Lombok que, además de incluir los campos en la clase actual, llame
//al método toString() de la super clase (clase padre). Esto permite que la representación en cadena
//incluya también los campos heredados.
public class Empleado extends Persona{
    //La palabra reservada extends indica que la clase extiende o hereda de otra clase.
    //La clase hija está obligada a implementar todos los métodos abstractos de su clase padre.
    private int legajo;
    private float sueldoBasico;
    
    public Empleado(String nombre, String apellido, int edad, Direccion direccion, int legajo, float sueldoBasico) {
        super(nombre, apellido, edad, direccion);
        this.legajo = legajo;
        this.sueldoBasico = sueldoBasico;
    }

    @Override //La anotattion @Override no es obligatoria, se deja como buena práctica y porque a veces, herramientas
             //externas leen las distintas anotaciones.
    public void saludar() {
        System.out.println("Hola, soy un empleado!");
    }
    @Override 
    public void despedir(){
        System.out.println("Chau, jefe!");
    }
}
