package ar.com.centro8.java.curso.ejercicio.herencia.figuras.entidades;

public abstract class Figura {
    public abstract double perimetro();
    public abstract double superficie();
}