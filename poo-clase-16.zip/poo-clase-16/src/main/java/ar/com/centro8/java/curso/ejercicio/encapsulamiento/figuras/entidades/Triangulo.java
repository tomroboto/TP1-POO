package ar.com.centro8.java.curso.ejercicio.encapsulamiento.figuras.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter
@ToString
@AllArgsConstructor

public class Triangulo extends Figura{
    private double base;
    private double altura;

    @Override
    public double perimetro() {
        return base+altura+Math.hypot(base, altura);
    }
    @Override
    public double superficie() {
        return (base*altura)/2;
    }
}
