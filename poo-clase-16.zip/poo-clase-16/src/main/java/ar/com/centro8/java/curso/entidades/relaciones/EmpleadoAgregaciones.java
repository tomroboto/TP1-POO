package ar.com.centro8.java.curso.entidades.relaciones;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString

public class EmpleadoAgregaciones {
    // Las agregaciones son un tipo de relación un poco más fuerte entre clases.
    // Son de las más utilizadas.
    // Las reconocemos con las palabras "tiene un/a".
    // Por ejemplo, en este caso, un empleado tiene un auto.

    private int legajo;
    private String nombre;
    private String apellido;
    private Auto auto;

    // Creamos un constructor sin auto, el auto se agrega después con un setter, ya que es opcional
    public EmpleadoAgregaciones(int legajo, String nombre, String apellido) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
}
