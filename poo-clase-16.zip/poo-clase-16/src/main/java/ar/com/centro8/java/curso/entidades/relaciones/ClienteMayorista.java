package ar.com.centro8.java.curso.entidades.relaciones;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString 


public class ClienteMayorista {
    //Atributos
    private int nro;
    private String razonSocial;
    private String direccion;
    private List<Cuenta> cuentas= new ArrayList<>();
    
    public ClienteMayorista(int nro, String razonSocial, String direccion) {
        this.nro = nro;
        this.razonSocial = razonSocial;
        this.direccion = direccion;
    }

    
}
