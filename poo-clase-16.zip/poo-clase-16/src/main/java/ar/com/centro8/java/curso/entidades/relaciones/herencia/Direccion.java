package ar.com.centro8.java.curso.entidades.relaciones.herencia;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor 

public class Direccion {
    private String calle;
    private int numero;
    private String piso;
    private String departamento;
    private String ciudad;

}
